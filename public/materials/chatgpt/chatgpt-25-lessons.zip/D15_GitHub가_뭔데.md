# [강좌] D15. GitHub가 뭔데 — 클라우드 세이브와 협업 게시판

> Codex 앱 선택 심화 · Windows 중심 · 공식 확인: 2026-11-14
> 먼저 읽을 강의: D03.

## 3줄요약

1. **Git은 내 PC의 세이브 기록, GitHub는 그 기록을 올려두는 클라우드 + 협업 게시판**이다.
2. 연습 저장소는 처음부터 **Private(비공개)**로 만든다.
3. 저장소를 만들었다는 말보다 **GitHub 웹에서 직접 열어 본 것**이 완료 증거다.

## 1. 준비와 오늘의 결과

[GitHub 연습 안내](실습자료/06_GitHub_연습안내.md)를 연다. 오늘 결과는 **비공개 연습 저장소 1개와 README 한 줄**이다. GitHub 계정이 없다면 github.com에서 가입부터 한다. 비밀번호와 인증 코드는 직접 입력하고, AI에게 알려주지 않는다.

## 2. Git과 GitHub 구분하기

| | Git | GitHub |
|---|---|---|
| 어디 있나 | 내 PC | 인터넷(github.com) |
| 하는 일 | 변경 기록 저장(커밋) | 기록 보관·공유·협업(PR·이슈) |
| 비유 | 게임 세이브 파일 | 클라우드 세이브 + 게시판 |
| 없으면 | 되돌리기 어려움 | PC가 고장 나면 기록도 같이 날아감 |

GitHub를 쓰면 좋은 경우: 내 작업을 백업할 때, 다른 사람과 같이 고칠 때, B09처럼 Vercel 같은 서비스에 연결해 배포할 때.

## 3. 비공개 연습 저장소 만들기

1. github.com에 로그인 → 오른쪽 위 `+` → **New repository** (메뉴 이름은 바뀔 수 있음)
2. 이름: `my-gagyebu-practice` (가짜 이름)
3. 공개 범위: **Private** 선택
4. "Add a README" 같은 선택지가 있으면 체크
5. 만든 뒤 저장소 화면에서 **자물쇠 표시 / Private 표시**를 확인

AI에게 도움을 받을 때는 이렇게 묻는다.

> GitHub 웹에서 비공개 저장소를 처음 만들려고 해. 내 화면에는 (보이는 버튼 이름)이 있어. 다음에 뭘 눌러야 하는지 단계별로 알려줘. 비밀번호나 인증 코드는 묻지 마.

## 4. 주의 사항

- 첫 실습은 **비공개 저장소 + 가짜 데이터**로만 한다.
- 계정명·다른 비공개 저장소 이름이 보이는 화면은 캡처해서 공유하지 않는다.
- GitHub 로그인, 2단계 인증 코드, 토큰은 **내가 직접** 처리한다. 채팅에 붙여넣지 않는다.
- 화면 메뉴 이름은 업데이트로 바뀔 수 있다. 보이는 이름을 그대로 적어두고 공식 문서로 확인한다.

## 5. 이렇게는 쓰지 말자

| ❌ 이렇게 하지 말자 | ✅ 대신 이렇게 | 이유 |
|---|---|---|
| "일단 Public으로 만들고 나중에 비공개로 바꾸자" | 처음부터 Private | 공개된 동안 누가 복사했는지 알 수 없다 |
| 실제 회사 엑셀로 첫 실습 | 실습자료의 가짜 CSV | 회사 정책 위반·유출 위험 |
| "내 GitHub 비밀번호는 ○○야, 로그인해줘" | 로그인은 내가 직접 | 비밀번호를 AI에 주면 안 된다 |
| 저장소 화면 전체 캡처를 단톡방에 공유 | 필요한 부분만, 계정명 가리고 | 계정명·다른 저장소 이름이 노출된다 |

## 6. 확인 방법과 막혔을 때

- 저장소 화면에 Private 표시가 있는지 직접 본다.
- README가 보이면 성공이다. 안 보이면 README 추가 버튼으로 한 줄 써서 저장(Commit)한다.
- 가입·인증 단계가 막히면 GitHub 공식 도움말을 따른다. AI에게는 "보이는 화면 문구"만 전달한다.

## 화면 보며 따라 하기

**준비:** GitHub 계정과 연습 저장소 이름을 준비합니다.

[공통 실습 파일 ZIP 받기](/materials/walkthrough/cd-practice-starter.zip) · ZIP을 모두 푼 뒤 00_먼저읽기.md부터 확인합니다.

**내 화면에서:** 같은 GitHub 화면을 재사용합니다. Codex가 없어도 GitHub의 저장소·README를 읽을 수 있습니다.

1. 로그인 뒤 + → New repository를 엽니다. 그림의 설정 위치만 참고하고 내 이름·Private·README 추가를 확인합니다.
2. 이미 만든 연습 저장소가 있다면 다시 만들지 말고 그 저장소를 엽니다.
3. 저장소 화면의 Private 표시와 README를 직접 확인합니다. Code라는 초록 버튼은 GitHub의 복제 메뉴입니다.

**완료 확인**

- Private 표시·README·정확한 저장소 주소
- 앱의 Code 화면과 GitHub Code 버튼을 구분

**막혔을 때:** 원본 그림이 Public·README Off 상태이면 그대로 따라 만들지 않습니다. 이번 연습은 Private·README On입니다. GitHub 웹 로그인과 로컬 Git 인증은 별개일 수 있습니다.

![따라 하기 화면](/materials/setup/github-menu.jpg)

![따라 하기 화면](/materials/setup/github-form.jpg)

**이번 검토에서 확인한 범위:** 첨부 가이드의 실제 GitHub 화면을 재사용했습니다. 새 GitHub 연습 저장소를 생성한 증거는 아닙니다.

## 숙제

1. 비공개 연습 저장소 `my-gagyebu-practice`를 만든다.
2. README에 "가계부 연습 저장소. 가짜 데이터만 씀." 한 줄을 쓴다.
3. Git과 GitHub의 차이를 내 말로 한 줄 적는다.

## 확인 퀴즈

4지선다 5문항입니다. 먼저 답을 고른 뒤 아래 해설을 확인하세요.

### Q1. Git과 GitHub의 관계로 맞는 것은?

- A. 같은 프로그램의 다른 이름이다
- B. Git은 내 PC의 기록, GitHub는 기록을 올려두고 함께 쓰는 곳이다
- C. GitHub가 없으면 Git을 쓸 수 없다
- D. Git은 웹사이트, GitHub는 내 PC 프로그램이다

### Q2. 연습 저장소의 공개 범위는?

- A. 처음부터 Private
- B. Public으로 만들고 나중에 변경
- C. 상관없음
- D. 회사 계정으로 Public

### Q3. GitHub 로그인 인증 코드를 AI에게 알려줘도 될까?

- A. 빠르니까 괜찮다
- B. 비공개 저장소면 괜찮다
- C. 한 번만이면 괜찮다
- D. 안 된다. 로그인과 인증은 내가 직접 한다

### Q4. 저장소를 만들었다는 완료 증거는?

- A. AI가 "만들었습니다"라고 답함
- B. 브라우저를 닫음
- C. GitHub 웹에서 저장소와 Private 표시를 직접 확인함
- D. 저장소 이름을 메모함

### Q5. 메뉴 이름이 강의와 다를 때는?

- A. 보이는 이름을 적고 공식 문서로 확인한다
- B. 아무 버튼이나 눌러본다
- C. 고장이라고 판단한다
- D. 다른 사람 계정으로 로그인한다

## 정답과 해설

1. **B** — Git은 기록 도구, GitHub는 그 기록을 보관·공유하는 서비스다.

2. **A** — 공개 상태였던 동안의 노출은 되돌릴 수 없다.

3. **D** — 인증 정보는 본인만 다룬다.

4. **C** — 답변 문구와 실제 결과는 다르다. 직접 확인한다.

5. **A** — 화면은 바뀔 수 있다. 추측 대신 기록하고 확인한다.

## 념글 박제

GitHub 첫 단추는 Private. 공개는 언제든 할 수 있지만 비공개로 되돌린다고 없던 일이 되진 않음.

## 공식 참고

확인일: 2026-11-14. 계정·버전·조직 설정에 따라 제공 범위가 다를 수 있습니다.

- [GitHub와 Git 소개](https://docs.github.com/en/get-started/start-your-journey/about-github-and-git)
- [새 저장소 만들기](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)
- [저장소 공개 범위 설정](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/managing-repository-settings/setting-repository-visibility)
- [Codex 실행 환경](https://learn.chatgpt.com/docs/environments/modes)

[전체 목차로](00_읽는법.md) · [실습 자료 안내](실습자료/00_실습자료_안내.md)

**학습 순서:** [이전 D14](D14_Codex_앱에서_첫_앱_만들기.md) · [다음 D16](D16_GitHub_사고_방지.md)
